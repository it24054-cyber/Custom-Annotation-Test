import java.lang.annotation.*;

/**
 * Maps a URL path to a method.
 * The spec names the element path(); the starter code writes @Route("/hello"),
 * which Java only allows for an element called value(). So both are supported:
 * use either @Route("/x") or @Route(path = "/x").
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Route {
    String path() default "";
    String value() default "";
}
