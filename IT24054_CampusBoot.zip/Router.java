import java.lang.reflect.Method;

public class Router {
    public static String dispatch(Container c, String path) {
        for (Object bean : c.allBeans()) {
            for (Method m : bean.getClass().getDeclaredMethods()) {
                Route r = m.getAnnotation(Route.class);
                if (r != null && path.equals(r.path().isEmpty() ? r.value() : r.path())) {
                    try {
                        m.setAccessible(true);
                        return (String) m.invoke(bean);
                    } catch (ReflectiveOperationException e) {
                        throw new RuntimeException("Failed to invoke " + m.getName(), e);
                    }
                }
            }
        }
        return "404 Not Found: " + path;
    }
}
